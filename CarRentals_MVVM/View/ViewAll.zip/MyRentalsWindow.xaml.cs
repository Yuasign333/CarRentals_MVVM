﻿using System.Windows;
using System.Windows.Input;
using CarRentals_MVVM.Services;
using CarRentals_MVVM.ViewModels;

namespace CarRentals_MVVM.View
{
    public partial class MyRentalsWindow : Window
    {
        public MyRentalsWindow(string userId)
        {
            InitializeComponent();
            this.Loaded += (s, e) => NavigationService.SetCurrent(this);
            this.DataContext = new StubWindowViewModel(userId, isAdmin: false);
        }

        private void BackBtn_Click(object sender, MouseButtonEventArgs e)
        { if (DataContext is StubWindowViewModel vm) vm.BackCommand.Execute(null); }
    }
}