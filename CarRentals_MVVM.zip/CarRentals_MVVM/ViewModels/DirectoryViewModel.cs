﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using CarRentals_MVVM.Commands;
using CarRentals_MVVM.Models;

namespace CarRentals_MVVM.ViewModels
{
    public class DirectoryViewModel : ObservableObject
    {
        public ObservableCollection<LostItemsModel> LostItemsList { get; set; } = new();

        public ICommand SaveCommand   { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand ClearCommand  { get; set; }

        //New item fields  (with OnPropertyChanged)
        private string _newItemName = string.Empty;
        public string NewItemName
        {
            get => _newItemName;
            set { _newItemName = value; OnPropertyChanged(); }
        }

        private string _newDescription = string.Empty;
        public string NewDescription
        {
            get => _newDescription;
            set { _newDescription = value; OnPropertyChanged(); }
        }

        private string _newLocationLost = string.Empty;
        public string NewLocationLost
        {
            get => _newLocationLost;
            set { _newLocationLost = value; OnPropertyChanged(); }
        }

        private DateTime? _newDateReported = DateTime.Now;
        public DateTime? NewDateReported
        {
            get => _newDateReported;
            set { _newDateReported = value; OnPropertyChanged(); }
        }

        //Selected item
        private LostItemsModel? _selectedLostItems;
        public LostItemsModel? SelectedLostItems
        {
            get => _selectedLostItems;
            set
            {
                _selectedLostItems = value;
                OnPropertyChanged();

                // Auto-fill form fields when a row is selected
                if (_selectedLostItems != null)
                {
                    NewItemName     = _selectedLostItems.ItemName;
                    NewDescription  = _selectedLostItems.Description;
                    NewLocationLost = _selectedLostItems.LocationLost;
                    NewDateReported = _selectedLostItems.DateReported;
                }
            }
        }

        public DirectoryViewModel()
        {
            LostItemsList = new ObservableCollection<LostItemsModel>
            {
                new LostItemsModel { ItemName="Wallet",     Description="Black leather",          LocationLost="Library",   DateReported=new DateTime(2024,5,10), IsFound=false },
                new LostItemsModel { ItemName="Keys",       Description="Set of house keys",      LocationLost="Cafeteria", DateReported=new DateTime(2024,5,12), IsFound=false },
                new LostItemsModel { ItemName="BackPack",   Description="Blue with white stripe", LocationLost="School",    DateReported=new DateTime(2024,5,10), IsFound=false },
                new LostItemsModel { ItemName="Umbrella",   Description="Black folding umbrella", LocationLost="Parking",   DateReported=new DateTime(2024,5,13), IsFound=false },
                new LostItemsModel { ItemName="Headphones", Description="White wireless earbuds", LocationLost="Gym",       DateReported=new DateTime(2024,5,14), IsFound=false },
            };

            SaveCommand   = new RelayCommand(ExecuteSaveCommand);
            DeleteCommand = new RelayCommand(ExecuteDeleteCommand);
            ClearCommand  = new RelayCommand(ExecuteClearCommand);
        }

        public void ExecuteSaveCommand(object? par)
        {
            if (string.IsNullOrWhiteSpace(NewItemName))
            {
                MessageBox.Show("Item Name is required.", "Validation",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            LostItemsList.Add(new LostItemsModel
            {
                ItemName     = NewItemName,
                Description  = NewDescription,
                LocationLost = NewLocationLost,
                DateReported = NewDateReported ?? DateTime.Now,
                IsFound      = false
            });

            MessageBox.Show("New Record Added", "Success",
                MessageBoxButton.OK, MessageBoxImage.Information);

            ExecuteClearCommand(null);
        }


        public void ExecuteDeleteCommand(object? par)
        {
            if (SelectedLostItems == null)
            {
                MessageBox.Show("Please select a row to delete.", "No Selection",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            else
            {
                MessageBox.Show("Item Succesfully Deleted.", "Delete",
                MessageBoxButton.OK, MessageBoxImage.Information);

                LostItemsList.Remove(SelectedLostItems);
                ExecuteClearCommand(null); // clear form after delete

                
                return;
            }
        }
        public void ExecuteClearCommand(object? par)
        {
            NewItemName     = string.Empty;
            NewDescription  = string.Empty;
            NewLocationLost = string.Empty;
            NewDateReported = DateTime.Now;
            SelectedLostItems = null;

            MessageBox.Show("Inputs cleared.", "Clear",
        MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
    }
}