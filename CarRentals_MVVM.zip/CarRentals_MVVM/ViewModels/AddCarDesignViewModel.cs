﻿// ─────────────────────────────────────────────────────────────────────────────
// Design-time only ViewModel for AddCarWindow.xaml.
// Provides fake car list data so the Visual Studio designer shows a preview
// of the fleet table on the left side of the window.
// This class is NEVER used at runtime — only in the XAML designer.
// Connected to: AddCarWindow.xaml (via d:DataContext)
// ─────────────────────────────────────────────────────────────────────────────

using System.Collections.ObjectModel;
using CarRentals_MVVM.Models;

namespace CarRentals_MVVM.ViewModels
{
    public class AddCarDesignViewModel
    {
        // ── Display labels ─────────────────────────────────────────────────────

        /// <summary>
        /// Fake user label shown in the top-right badge in the designer.
        /// </summary>
        public string UserLabel { get; } = "Agent: A001";

        /// <summary>
        /// Fake auto-generated Car ID shown in the read-only Car ID field.
        /// In the real ViewModel this is computed by GenerateNextId().
        /// </summary>
        public string NextCarId { get; } = "C007";

        // ── Form field defaults (shown on the right side of the window) ────────

        /// <summary>Fake car name shown in the Name field in the designer.</summary>
        public string NewName { get; set; } = "Toyota Camry";

        /// <summary>Fake category shown in the Category ComboBox in the designer.</summary>
        public string NewCategory { get; set; } = "Sedan";

        /// <summary>Fake fuel type shown in the Fuel Type ComboBox in the designer.</summary>
        public string NewFuelType { get; set; } = "Standard Engine";

        /// <summary>Fake price shown in the Price Per Hour field in the designer.</summary>
        public decimal NewPricePerHour { get; set; } = 40;

        /// <summary>Fake status shown in the Status ComboBox in the designer.</summary>
        public string NewStatus { get; set; } = "Available";

        /// <summary>Fake image URL shown in the Image URL field in the designer.</summary>
        public string NewImageUrl { get; set; } = "https://i.imgur.com/gMFP5tP.jpeg";

        // ── Car list (shown on the left side of the window) ───────────────────

        /// <summary>
        /// Fake car list shown in the table on the left side of AddCarWindow.
        /// Includes all three status types so badge colors can be previewed.
        /// Matches the seed data in CarDataService.
        /// </summary>
        public ObservableCollection<CarModel> CarList { get; } = new()
        {
            new CarModel
            {
                CarId           = "C001",
                Name            = "Toyota Camry",
                Category        = "Sedan",
                FuelType        = "Standard Engine",
                Status          = "Available",
                PricePerHour    = 40,
                ImageUrl        = "https://i.imgur.com/gMFP5tP.jpeg",
                AvailableColors = [ "White", "Gray" ]
            },
            new CarModel
            {
                CarId           = "C002",
                Name            = "Ford Explorer",
                Category        = "SUV",
                FuelType        = "Standard Engine",
                Status          = "Available",
                PricePerHour    = 75,
                ImageUrl        = "https://i.imgur.com/vgEvOtG.jpeg",
                AvailableColors = [ "White" ]
            },
            new CarModel
            {
                CarId           = "C003",
                Name            = "Honda Civic",
                Category        = "Sedan",
                FuelType        = "Standard Engine",
                Status          = "Available",
                PricePerHour    = 35,
                ImageUrl        = "https://i.imgur.com/adLesJ3.jpeg",
                AvailableColors = [ "White", "Red", "Blue" ]
            },
            new CarModel
            {
                CarId           = "C004",
                Name            = "Tesla Model 3",
                Category        = "Sedan",
                FuelType        = "EV",
                Status          = "Available",
                PricePerHour    = 65,
                ImageUrl        = "https://i.imgur.com/69GQ8YT.jpeg",
                AvailableColors = [ "White" ]
            },
            new CarModel
            {
                CarId           = "C005",
                Name            = "Toyota HiAce",
                Category        = "Van",
                FuelType        = "Standard Engine",
                Status          = "Available",
                PricePerHour    = 80,
                ImageUrl        = "https://i.imgur.com/UN1XHVO.jpeg",
                AvailableColors = [ "White", "Black" ]
            },
            new CarModel
            {
                CarId           = "C006",
                Name            = "Hyundai Tucson",
                Category        = "SUV",
                FuelType        = "Standard Engine",
                Status          = "Maintenance",
                PricePerHour    = 55,
                ImageUrl        = "https://i.imgur.com/iWOAwIV.jpeg",
                AvailableColors = [ "White", "Black", "Blue" ]
            },
        };
    }
}