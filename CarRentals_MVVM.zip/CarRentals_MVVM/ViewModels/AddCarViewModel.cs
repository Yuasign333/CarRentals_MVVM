﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using CarRentals_MVVM.Commands;
using CarRentals_MVVM.Models;
using CarRentals_MVVM.Services;

namespace CarRentals_MVVM.ViewModels
{
    public class AddCarViewModel : ObservableObject
    {
        private readonly string _userId;
        public string UserLabel { get; }

        public ObservableCollection<CarModel> CarList { get; set; } = new();

        // ── Selected car ─────────────────────────────────────
        private CarModel? _selectedCar;
        public CarModel? SelectedCar
        {
            get => _selectedCar;
            set
            {
                _selectedCar = value;
                OnPropertyChanged();
                if (_selectedCar != null)
                {
                    NewCarId = _selectedCar.CarId;
                    NewName = _selectedCar.Name;
                    NewCategory = _selectedCar.Category;
                    NewFuelType = _selectedCar.FuelType;
                    NewPricePerHour = _selectedCar.PricePerHour;
                    NewStatus = _selectedCar.Status;
                    NewImageUrl = _selectedCar.ImageUrl;
                }
            }
        }

        // ── Form fields ───────────────────────────────────────
        private string _newCarId = string.Empty;
        public string NewCarId
        {
            get => _newCarId;
            set { _newCarId = value; OnPropertyChanged(); }
        }

        private string _newName = string.Empty;
        public string NewName
        {
            get => _newName;
            set { _newName = value; OnPropertyChanged(); }
        }

        private string _newCategory = "Sedan";
        public string NewCategory
        {
            get => _newCategory;
            set { _newCategory = value; OnPropertyChanged(); }
        }

        private string _newFuelType = "Standard Engine";
        public string NewFuelType
        {
            get => _newFuelType;
            set { _newFuelType = value; OnPropertyChanged(); }
        }

        private decimal _newPricePerHour;
        public decimal NewPricePerHour
        {
            get => _newPricePerHour;
            set { _newPricePerHour = value; OnPropertyChanged(); }
        }

        private string _newStatus = "Available";
        public string NewStatus
        {
            get => _newStatus;
            set { _newStatus = value; OnPropertyChanged(); }
        }

        private string _newImageUrl = string.Empty;
        public string NewImageUrl
        {
            get => _newImageUrl;
            set { _newImageUrl = value; OnPropertyChanged(); }
        }

        // ── Commands ──────────────────────────────────────────
        public ICommand BackCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand ClearCommand { get; }

        public AddCarViewModel(string userId)
        {
            _userId = userId;
            UserLabel = $"Agent: {userId}";

            // Load cars from shared data service
            foreach (var car in CarDataService.Cars)
                CarList.Add(car);

            BackCommand = new RelayCommand(_ =>
                NavigationService.Navigate(new View.AdminDashboard(_userId)));

            SaveCommand = new RelayCommand(_ =>
            {
                if (string.IsNullOrWhiteSpace(NewCarId) || string.IsNullOrWhiteSpace(NewName))
                {
                    MessageBox.Show("Car ID and Name are required.", "Validation",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var newCar = new CarModel
                {
                    CarId = NewCarId,
                    Name = NewName,
                    Category = NewCategory,
                    FuelType = NewFuelType,
                    PricePerHour = NewPricePerHour,
                    Status = NewStatus,
                    ImageUrl = NewImageUrl,
                    AvailableColors = ["White", "Black", "Silver"]
                };

                CarDataService.Cars.Add(newCar);
                CarList.Add(newCar);

                MessageBox.Show("Car added successfully!", "Success",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                ExecuteClear();
            });

            DeleteCommand = new RelayCommand(_ =>
            {
                if (SelectedCar == null)
                {
                    MessageBox.Show("Please select a car to delete.", "No Selection",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                CarDataService.Cars.Remove(SelectedCar);
                CarList.Remove(SelectedCar);
                ExecuteClear();
            });

            ClearCommand = new RelayCommand(_ => ExecuteClear());
        }

        private void ExecuteClear()
        {
            NewCarId = string.Empty;
            NewName = string.Empty;
            NewCategory = "Sedan";
            NewFuelType = "Standard Engine";
            NewPricePerHour = 0;
            NewStatus = "Available";
            NewImageUrl = string.Empty;
            SelectedCar = null;
        }
    }
}