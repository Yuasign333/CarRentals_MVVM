﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using CarRentals_MVVM.Services;
using CarRentals_MVVM.Models;
using CarRentals_MVVM.ViewModels;

namespace CarRentals_MVVM.View
{
    public partial class Directory : Window
    {
        public Directory()
        {
            InitializeComponent();
            NavigationService.SetCurrent(this);
            this.DataContext = new ViewModels.DirectoryViewModel();
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e) { }

        private void Button_Click(object sender, RoutedEventArgs e) //Add
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //Clear
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e) //Delete 
        {

        }
    }
}