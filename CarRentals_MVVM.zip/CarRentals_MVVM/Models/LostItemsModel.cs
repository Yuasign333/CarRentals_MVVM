﻿using CarRentals_MVVM.ViewModels;

namespace CarRentals_MVVM.Models
{
    public class LostItemsModel : ObservableObject
    {
        private string _itemName = string.Empty;
        private string _description = string.Empty;
        private string _locationLost = string.Empty;
        private DateTime _dateReported = DateTime.Now;
        private bool _isFound = false;

        public string ItemName
        {
            get => _itemName;
            set { if (_itemName != value) { _itemName = value; OnPropertyChanged(); } }
        }

        public string Description
        {
            get => _description;
            set { if (_description != value) { _description = value; OnPropertyChanged(); } }
        }

        public string LocationLost
        {
            get => _locationLost;
            set { if (_locationLost != value) { _locationLost = value; OnPropertyChanged(); } }
        }

        public DateTime DateReported
        {
            get => _dateReported;
            set { if (_dateReported != value) { _dateReported = value; OnPropertyChanged(); } }
        }

        public bool IsFound
        {
            get => _isFound;
            set { if (_isFound != value) { _isFound = value; OnPropertyChanged(); } }
        }
    }
}